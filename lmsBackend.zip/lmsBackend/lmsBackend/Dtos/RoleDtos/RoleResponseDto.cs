﻿namespace lmsBackend.Dtos.RoleDtos
{
    public class RoleResponseDto
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; } = string.Empty;
    }
}
